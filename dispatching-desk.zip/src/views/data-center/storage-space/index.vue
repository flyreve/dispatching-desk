<!--page: 存储空间-->
<template>
  <div class="storage-space width-page">
    <h3>存储空间</h3>
  </div>
</template>

<script>
  export default {
    name: 'storage-space',
    data() {
      return {}
    },
    mounted() {
    },
    methods: {}
  }
</script>

<style scoped></style>
