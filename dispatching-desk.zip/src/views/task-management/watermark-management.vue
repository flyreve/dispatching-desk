<!--page: 水印管理-->
<template>
  <div class="watermark-management page">
    <el-card class="main-1-card">
      <div slot="header">
        <span class="fz-16">水印管理</span>
      </div>
    </el-card>
  </div>
</template>

<script>
  export default {
    name: 'watermark-management',
    data() {
      return {}
    },
    mounted() {
    },
    methods: {}
  }
</script>

<style scoped></style>
