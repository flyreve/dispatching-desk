<!--page: 地图图层-->
<template>
  <div class="map-layer page">
    <el-card class="main-1-card">
      <div slot="header">
        <span class="fz-16">地图图层</span>
      </div>
    </el-card>
  </div>
</template>

<script>
  export default {
    name: 'map-layer',
    data() {
      return {}
    },
    mounted() {
    },
    methods: {}
  }
</script>

<style scoped></style>
