const getters = {
  navMenuList: state => state['menu'].navMenuList,
  navMenuActive: state => state['menu'].navMenuActive,
  sideMenuList: state => state['menu'].sideMenuList,
}
export default getters
